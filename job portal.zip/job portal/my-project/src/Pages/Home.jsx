const Home = () => {
  return (
    <div className="text-blue">Home Page</div>
  )
}

export default Home